﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1

    {
        [TestMethod]
        #kirt

        public void TestMethod1()
        {
        }
    }
}
